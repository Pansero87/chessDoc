var searchData=
[
  ['king_0',['King',['../classpieces_1_1_king.html#a9634b953030b6a6bb696465a24136481',1,'pieces::King']]],
  ['knight_1',['Knight',['../classpieces_1_1_knight.html#a7b44cc95254941c0c3f143b824e2401c',1,'pieces::Knight']]]
];
