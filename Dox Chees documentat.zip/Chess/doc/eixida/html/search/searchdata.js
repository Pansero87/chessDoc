var indexSectionsWithContent =
{
  0: "bgikmpqrs",
  1: "bkpqr",
  2: "p",
  3: "bkpqr",
  4: "bgikmpqrs",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Espacios de nombres",
  3: "Archivos",
  4: "Funciones",
  5: "Variables"
};

