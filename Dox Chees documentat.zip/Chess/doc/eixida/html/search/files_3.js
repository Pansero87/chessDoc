var searchData=
[
  ['queen_2ejava_0',['Queen.java',['../_queen_8java.html',1,'']]]
];
