var searchData=
[
  ['pawn_0',['Pawn',['../classpieces_1_1_pawn.html',1,'pieces']]],
  ['piece_1',['Piece',['../classpieces_1_1_piece.html',1,'pieces']]]
];
