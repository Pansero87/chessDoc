var searchData=
[
  ['queen_0',['Queen',['../classpieces_1_1_queen.html',1,'pieces.Queen'],['../classpieces_1_1_queen.html#a61d2586dcb3da3d2f521293599b04fb3',1,'pieces.Queen.Queen()']]],
  ['queen_2ejava_1',['Queen.java',['../_queen_8java.html',1,'']]]
];
