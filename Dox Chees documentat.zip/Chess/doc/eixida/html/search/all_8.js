var searchData=
[
  ['setcolor_0',['setColor',['../classpieces_1_1_piece.html#af12d507d80028bbb0d861becb4037363',1,'pieces::Piece']]],
  ['setid_1',['setId',['../classpieces_1_1_piece.html#af2fdd1dcd575e9fcd0eef32b42aa846b',1,'pieces::Piece']]],
  ['setpath_2',['setPath',['../classpieces_1_1_piece.html#aed21b88c46f8a7e7d6670d7f61afab33',1,'pieces::Piece']]],
  ['setx_3',['setx',['../classpieces_1_1_king.html#a50abc32a712bcea91dd14ab56271fb3e',1,'pieces::King']]],
  ['sety_4',['sety',['../classpieces_1_1_king.html#ad2cc9233c35a950bedc47bf7626d0b4d',1,'pieces::King']]]
];
