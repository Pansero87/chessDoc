var searchData=
[
  ['rook_0',['Rook',['../classpieces_1_1_rook.html',1,'pieces']]]
];
