var searchData=
[
  ['queen_0',['Queen',['../classpieces_1_1_queen.html#a61d2586dcb3da3d2f521293599b04fb3',1,'pieces::Queen']]]
];
