var searchData=
[
  ['pieces_0',['pieces',['../namespacepieces.html',1,'']]]
];
