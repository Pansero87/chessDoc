var searchData=
[
  ['isindanger_0',['isindanger',['../classpieces_1_1_king.html#ac3d94b4b9dd3de4087ff22a2a0389a19',1,'pieces::King']]]
];
