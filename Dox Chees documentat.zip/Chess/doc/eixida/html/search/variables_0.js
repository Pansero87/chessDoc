var searchData=
[
  ['possiblemoves_0',['possiblemoves',['../classpieces_1_1_piece.html#a350d60ec36892a34774d287da8cae1e2',1,'pieces::Piece']]]
];
