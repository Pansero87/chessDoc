var searchData=
[
  ['king_0',['King',['../classpieces_1_1_king.html',1,'pieces']]],
  ['knight_1',['Knight',['../classpieces_1_1_knight.html',1,'pieces']]]
];
