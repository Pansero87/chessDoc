var searchData=
[
  ['getcolor_0',['getcolor',['../classpieces_1_1_piece.html#a70a3ab5805026ad22d75e82eba4aaf95',1,'pieces::Piece']]],
  ['getcopy_1',['getcopy',['../classpieces_1_1_piece.html#a00df1840a079c87feb136555e1e7d62d',1,'pieces::Piece']]],
  ['getid_2',['getId',['../classpieces_1_1_piece.html#ad87aca569644e35fb0d4cd2006cccd6d',1,'pieces::Piece']]],
  ['getpath_3',['getPath',['../classpieces_1_1_piece.html#a83ca02d8f33d50dc4fcfc8934dca902d',1,'pieces::Piece']]],
  ['getx_4',['getx',['../classpieces_1_1_king.html#af18ad8ae71d8f3b78f54ed079ebf0009',1,'pieces::King']]],
  ['gety_5',['gety',['../classpieces_1_1_king.html#a56357600c81542772091388891fe772b',1,'pieces::King']]]
];
